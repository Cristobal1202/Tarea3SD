import os
import requests
import json

entradas = [
    "mazda", "nissan", "toyota", "mitsubishi", "suzuki", 
    "bentley", "ferrari", "lamborghini", "lotus", "bugatti",
    "ford", "chevrolet", "honda", "hyundai", "kia",
    "porsche", "mercedes-benz", "audi", "bmw", "volkswagen",
    "jeep", "subaru", "volvo", "jaguar", "mclaren",
    "tesla", "fiat", "renault", "peugeot", "citroen"
]

# Verificar y crear los directorios si no existen
carpeta1_path = '../carpeta1/'
carpeta2_path = '../carpeta2/'
os.makedirs(carpeta1_path, exist_ok=True)
os.makedirs(carpeta2_path, exist_ok=True)

url = "https://en.wikipedia.org/w/api.php"
i = 1

for entrada in entradas:
    params = {
        'format': 'json',
        'action': 'query',
        'prop': 'extracts',
        'exintro': '',
        'explaintext': '',
        'redirects': 1,
        'titles': entrada
    }

    req = requests.get(
        url,
        params=params
    ).json()

    n_page = list(req['query']['pages'].keys())[0]
    texto = req['query']['pages'][n_page]['extract']
    texto = '{}<splittername>{}'.format(i, json.dumps(texto))

    if i <= 15:
        with open(os.path.join(carpeta1_path, f'{entrada}.txt'), 'w') as f:
            f.write(texto)
    else:
        with open(os.path.join(carpeta2_path, f'{entrada}.txt'), 'w') as f:
            f.write(texto)
    i += 1
